package com.example.patrimoine;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class Carte extends FragmentActivity implements OnMapReadyCallback {

    private final int SPLASH_SCREEN_TIMEOUT = 1000;

    private GoogleMap mMap;

    private Button accueil;
    private Button lieux;
    private Button contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carte);

        accueil = findViewById(R.id.accueil);
        accueil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accueil();
            }
        });

        lieux = findViewById(R.id.lieux);
        lieux.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lieux();
            }
        });

        contact = findViewById(R.id.contact);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contact();
            }
        });


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }

    private void lieux(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Lieux.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }

    private void accueil(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Accueil.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }
    private void contact(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Contact.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        float zoomLevel = 8.8f;

        // Add a marker in Sydney and move the camera
        LatLng museeGG = new LatLng(48.971483, 2.904421);
        mMap.addMarker(new MarkerOptions().position(museeGG).title("Musée de la Grande Guerre").snippet("9h30 - 18h, fermé mardi"));

        LatLng parcChamps = new LatLng(48.855012, 2.604314);
        mMap.addMarker(new MarkerOptions().position(parcChamps).title("Parc du Chateau de Champs").snippet("9h30 - 18h"));

        LatLng chateauChamps = new LatLng(48.855012, 2.604314);
        mMap.addMarker(new MarkerOptions().position(chateauChamps).title("Chateau de Champs").snippet("9h30 - 18h, fermé mardi"));

        LatLng chateauFontainebleau = new LatLng(48.402160, 2.699496);
        mMap.addMarker(new MarkerOptions().position(chateauFontainebleau).title("Chateau de Fontainebleau").snippet("9h30 - 18h, fermé mardi"));

        LatLng chateauVaux = new LatLng(48.566454, 2.714377);
        mMap.addMarker(new MarkerOptions().position(chateauVaux).title("Chateau de Vaux le Vicomte").snippet("10h - 19h"));

        LatLng moretLoing = new LatLng(48.36681, 2.827742);
        mMap.addMarker(new MarkerOptions().position(moretLoing).title("Moret sur Loing"));

        LatLng chateauBrieComte = new LatLng(48.692285, 2.610217);
        mMap.addMarker(new MarkerOptions().position(chateauBrieComte).title("Chateau de Brie-Comte-Robert").snippet("14h - 17h, samedi 14h30 - 18h"));

        LatLng provinsCite = new LatLng(48.560970, 3.281162);
        mMap.addMarker(new MarkerOptions().position(provinsCite).title("Provins - Cité Médiévale"));

        LatLng cimetiereAll = new LatLng(49.009156, 2.910702);
        mMap.addMarker(new MarkerOptions().position(cimetiereAll).title("Nécropole allemande de Chambry"));

        LatLng egliseLouis = new LatLng(48.405519, 2.701251);
        mMap.addMarker(new MarkerOptions().position(egliseLouis).title("Eglise Saint Louis"));

        LatLng egliseDameAnge = new LatLng(48.566454, 2.714377);
        mMap.addMarker(new MarkerOptions().position(egliseDameAnge).title("Eglise Notre-Dame des Anges"));

        LatLng museeSeineMarne = new LatLng(48.908100, 3.181679);
        mMap.addMarker(new MarkerOptions().position(museeSeineMarne).title("Musée départemental de la Seine et Marne").snippet("10h - 12h30, fermé samedi et mercredi"));

        LatLng jardinBourdelle = new LatLng(48.184267, 2.859644);
        mMap.addMarker(new MarkerOptions().position(jardinBourdelle).title("Jardin/Musée Bourdelle").snippet("mai à octobre 10h30-12h 14h-18h"));

        LatLng museeMalarme = new LatLng(48.431300, 2.746672);
        mMap.addMarker(new MarkerOptions().position(museeMalarme).title("Musée départemental Stephane Mallarmé").snippet("mars à octobre 10h-12h30 14h-17h30"));

        LatLng museePeintre = new LatLng(48.446283, 2.602639);
        mMap.addMarker(new MarkerOptions().position(museePeintre).title("Musée de Peintres de Barbizon").snippet("10h-12h30 14h-17h30"));

        LatLng paysOurcq = new LatLng(49.023955, 3.031276);
        mMap.addMarker(new MarkerOptions().position(paysOurcq).title("Pays de l'Ourcq"));

        LatLng chateauRosa = new LatLng(48.396218, 2.783191);
        mMap.addMarker(new MarkerOptions().position(chateauRosa).title("Chateau de Rosa Bonheur").snippet("11h-17h, fermé lundi"));

        LatLng chapelleGauthier = new LatLng(48.550842, 2.901409);
        mMap.addMarker(new MarkerOptions().position(chapelleGauthier).title("Chateau de la Chapelle Gauthier"));

        LatLng egliseArchere = new LatLng(48.356087, 2.571368);
        mMap.addMarker(new MarkerOptions().position(egliseArchere).title("Eglise Archères la Foret"));

        LatLng eglisePierreFlo = new LatLng(48.740317, 3.128651);
        mMap.addMarker(new MarkerOptions().position(eglisePierreFlo).title("Eglise St-Pierre et Ste-Flodoberthe"));

        LatLng egliseAssomption = new LatLng(48.267951, 2.561447);
        mMap.addMarker(new MarkerOptions().position(egliseAssomption).title("Eglise Notre Dame de l'Assomption"));

        LatLng egliseEloi = new LatLng(48.413959, 2.565323);
        mMap.addMarker(new MarkerOptions().position(egliseEloi).title("Eglise Saint Eloi"));

        LatLng eglisePierrePaul = new LatLng(48.187848, 2.547975);
        mMap.addMarker(new MarkerOptions().position(eglisePierrePaul).title("Eglise St-Pierre et St-Paul"));

        LatLng chapelleBonSecours = new LatLng(48.418495, 2.707611);
        mMap.addMarker(new MarkerOptions().position(chapelleBonSecours).title("Chapelle Notre Dame de Bon Secours"));

        LatLng egliseChristophe = new LatLng(48.630900, 2.886641);
        mMap.addMarker(new MarkerOptions().position(egliseChristophe).title("Eglise St Christophe d'Aubepierre"));

        LatLng chateauBlandy = new LatLng(48.567785, 2.780997);
        mMap.addMarker(new MarkerOptions().position(chateauBlandy).title("Chateau de Blandy les Tours").snippet("10h - 18h"));

        LatLng museeGD = new LatLng(48.545544, 2.652965);
        mMap.addMarker(new MarkerOptions().position(museeGD).title("Musée de la Gendarmerie Nationale").snippet("10h - 18h, fermé mardi"));

        LatLng chateauRentilly = new LatLng(48.740317, 3.128651);
        mMap.addMarker(new MarkerOptions().position(chateauRentilly).title("Chateau de Rentilly").snippet("9h - 20h"));

        LatLng parcEmprunt = new LatLng(48.189358, 2.724992);
        mMap.addMarker(new MarkerOptions().position(parcEmprunt).title("Parc de l'Emprunt").snippet("24h/24 les lundi"));

        LatLng parcAtilly = new LatLng(48.746057, 2.666059);
        mMap.addMarker(new MarkerOptions().position(parcAtilly).title("Parc du Bois d'Atilly").snippet("10h - 17h"));

        LatLng museeAero = new LatLng(48.740317, 3.128651);
        mMap.addMarker(new MarkerOptions().position(museeAero).title("Musée aéronautique et spacial du Groupe SAFRAN").snippet("mercredi 9h-12h 14h-17h"));


        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(egliseChristophe, zoomLevel));

    }


}
