package com.example.patrimoine;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Lieux extends AppCompatActivity {

    int[] IMAGES = {R.drawable.grande_guerre, R.drawable.parc_chateau_champs,R.drawable.chateau_champs,R.drawable.chateau_fontainebleau, R.drawable.chateau_vicomte,R.drawable.moret_loing, R.drawable.brie_comte,R.drawable.provins_medieval,R.drawable.cimetiere_allemand,R.drawable.eglise_st_louis,R.drawable.eglise_coulommier,R.drawable.musee_seine_marne,R.drawable.musee_jardin_bourdelle, R.drawable.maison_stephane,R.drawable.peintre_barbizon,R.drawable.crouy_ourcq, R.drawable.rosa_bonheur, R.drawable.chateau_chapelle_gauthier, R.drawable.eglise_archere, R.drawable.eglise_pierre_floberthe, R.drawable.eglise_dame_assomption, R.drawable.eglise_eloi,R.drawable.eglise_pierre_paul, R.drawable.chapelle_secours, R.drawable.eglise_aubepierre, R.drawable.chateau_blandy, R.drawable.musee_gd, R.drawable.chateau_rentilly, R.drawable.parc_emprunt, R.drawable.parc_atilly, R.drawable.musee_aeronautique};

    String[] MONUMENTS ={"Musée de la grande guerre","Parc du château de Champs","Chateau de Champs sur Marne","Chateau de Fontainebleau","Chateau de Vaux-le-Vicomte","Moret-sur-Loing","Château de Brie-Comte-Robert","Provins - Cité Médiévale","Cimetière militaire Allemand","Eglise Saint-Louis","Eglise Notre-Dame-Des-Anges","Musée départemental de la Seine-et-Marne","Musée/Jardin Bourdelle","Musée Stephane Malarmé","Musée des peintres de Barbizon","Pays de l'Ourcq","Château de Rosa Bonheur","Château de La Chapelle Gauthier","Eglise Archères-la-Forêt","Eglise St-Pierre et Ste-Flodoberthe","Église Notre-Dame-de-l'Assomption","Eglise Saint-Eloi","Eglise St-Pierre et Paul","Chapelle Notre-Dame-de-Bon-Secours","Eglise Saint-Christophe d'Aubepierre","Château de Blandy les Tours","Musée de la gendarmerie nati.","Château de Rentilly","Le parc de l'Emprunt ","Le parc du Bois d'Attilly","Musée aeronotique et spacial Safran"};
    String[] TYPES ={"Musée","Parc","Chateau","Chateau ","Chateau ","Historique","Chateau ","Historique","Cimetière","Eglise","Eglise","Musée","Musée","Musée","Musée","Historique","Chateau ","Chateau ","Eglise","Eglise","Eglise","Eglise","Eglise","Chapelle","Eglise","Chateau ","Musée","Chateau ","Parc","Parc","Historique"};
    String[] DESCRIPTIONS ={"Rassemblement d'une collection rare et diversifiée permettant d'aborder le conflit sur un plan technique et militaire des grandes guerres de l'époque.\nArmement, matériel, tenues et objets de la vie quotidienne sur le front seront ravir les passionnés.","Site classé depuis 1935, le parc de Champs sur Marne présente un double aspect : une partie centrale classique à la française et un parc à l'anglaise qui lui sert d'écrin.","Le château de Champs-sur-Marne est caractéristique des maisons de plaisance du XVIIIème siècle bâties à la campagne, permettant un nouvel art de vivre.  Construit de 1703 à 1708 par les architectes Pierre Bullet et Jean-Baptiste Bullet de Chamblain, à la demande du financier de Louis XIV","Utilisée par les rois de France dès le XIIe siècle, cette résidence fut dédié à la chasse, avant d'être embelli par François 1er. Entouré d'un vaste parc, cet endroit est un lieu de rencontre entre la Renaissance et la tradition française.","Conçu en 1650 et façonné par les plus grands artistes de l'époque, le chateau de Vaux-le-Vicomte impressionnat Louis XIV qui fit appel aux memes ouvriers.","Allez sur les pas d'Alfred Sisley, artiste peintre du XIXe siecle, et redécouvrez les motifs immortalisés durant les 10 années qu'il passait à Moret-sur-Loing.","Edifié au XIIe siecle par le comte Robert 1er de Dreux, le chateau a connu de nombreuses modifications. D'abord forteresse puis devenu résidence sous Jeanne d'Evreux, il fut restauré en 1982 par l'association 'les Amis du Vieux Chateau'.","Ville médiévale fortifié de Provins et situé au coeur de l'ancienne région des comtes de Champagne, elle témoigne des premiers développements des foires commerciales internationales et de l'industrie de la laine.","Petit cimetière regroupant les dépouilles de soldats allemands tombés au cours de la bataille de la Marne de 1914. 985 soldats ne sont toujours pas identifiés et chaque croix regroupe entre 2 et 4 soldats.","Relativement récente, ce n'est qu'au début du XVIIe siècle, sous le règne de Louis XIII, qu'une église fut construite pour desservir ce que l'on appelait le bourg. Il fallut attendre 1661 pour que Fontainebleau fût érigé en paroisse, desservie par les prêtres de la Mission (lazaristes).","Classé monument historique en 1930, elle est érigée en même temps que le couvent des Capucins en 1617 à la demande de Catherine de Gonzague, princesse de Clèves. Elle comporte une nef unique et une chapelle côté nord et a la particularité d'avoir un chœur sur 2 étages.","Situé dans le cadre campagnard de la vallée du petit Morin, le musée départemental de la Seine-et-Marne rassemble une collection de plus de 20 000 objets liés à l’activité agricole et artisanale de la société traditionnelle du département.","De style Art Déco, le musée-jardin départemental Bourdelle accueille 57 sculptures en bronze du célèbre sculpteur Antoine Bourdelle (1861-1929).","Le musée Stéphane Mallarmé se situe dans la maison de villégiature du poète symboliste, face à la Seine et à la forêt de Fontainebleau.","Entre 1830 et 1875, le village de Barbizon a été le principal lieu de résidence des peintres venus travailler en forêt de Fontainebleau à la recherche d’une nouvelle inspiration tirée de la nature.","Sur le chemin de l'Ourcq et du Multien, decouvrez un patrimoine industriel insolite et des villages pittoresques qui respirent la sérénité et la douceur de vivre. Venez contemplez les usines élévatoires de Tribardou et de Villiers-les-Rigault, témoins d'un patrimoine industriel prodigieux.","La maison de Rosa Bonheur, artiste peintre française du XIXème siècle, connue pour ses talents a été conservée dans l’état tel quel. Vous pouvez venir découvrir ses oeuvres mais aussi son atelier et son domaine. Tout est resté en l’état depuis 25 mai 1899.","Situé entre Melun et Provins le château dès de XIIè siècle a contribué au développement du commerce lié aux foires de Champagne. Ce château oublié de Seine et Marne est au coeur du village, son parc est inscrit dans le périmètre du site naturel classé du Val d'Ancoeur qui s'étend jusqu'au bassin du Château de Vaux le Vicomte.","La juxtaposition du clocher, de la nef, et du chœur, qui ne sont ni alignés ni d'égale hauteur fait la particularité de l'édifice. La nef, plafonnée, et le portail datent du XIIe siècle et le chœur, voûté d'ogives, au plus tôt du XVe siècle.","Son chœur gothique est restauré au XVIe siècle. A l'origine uniquement dédiée à Saint Pierre, le patronage de sainte Flodoberthe est ajoutée au XIIe siècle.","L'église Notre-Dame de l'Assomption jouxtait un ancien prieuré de l'Abbaye Saint Victor. Elle est construite dans un style commun en Gâtinais.","Cette église de plan rectangulaire a été édifiée au XIIIe siècle. Le chevet droit est percé de trois fenêtres en ogive et le clocher est couvert d'un toit en bâtière. Toutes les voûtes sont en pierre. Les fenêtres de l'abside et les chapiteaux sont des éléments caractéristiques du XIIIe siècle.","Edifice construit vers le milieu du XIIe siècle. Sa construction mêle des caractéristiques de l'art roman et du premier art gothique.","Inscrite en 1926 à l'inventaire des monuments historiques, la Chapelle Notre Dame du Bon Secours témoigne d'un fait miraculeux. Elle fut restaurée sous Napoléon III, mais conserve son aspect originel de 1690.","Eglise dédiée à saint Christophe, patron des voyageurs, car la région était autrefois parcourue par de nombreux voyageurs : pèlerins se rendant à Saint-Jacques-de-Compostelle, commerçants se dirigeant vers les foires de Champagne.","Construit entre les XIe et XIVe siècles, il a traversé l'histoire : manoir, château fort, château résidentiel puis simple ferme, avant de tomber en ruines. Une restauration d’envergure, menée par le Département, propriétaire du château depuis 1992, a redonné vie à la forteresse.","Un accès facilité, une architecture et une scénographie modernes, voilà ce qu’offre le musée de la Gendarmerie nationale, à Melun.","Le domaine culturel de Rentilly est un établissement public de la Communauté d’agglomération de Marne-et-Gondoire. Il a été ouvert au public en 2006 à la suite d’un vaste projet de réhabilitation financé en partie dans le cadre d’un contrat départemental de développement durable (C3D).","Ce parc abrite plus de 400 espèces d’animaux. Les visiteurs peuvent y découvrir des animaux familiers, comme les ânes, les moutons, et d’autres espèces plus sauvages (daims, sangliers). Certains animaux plus exotiques comme les lamas du Pérou ou les perruches de Patagonie y sont également présents.","Sur 19 hectares, le parc zoologique d’Attilly héberge plus de 300 animaux représentant 75 espèces de mammifères et d’oiseaux. Ses allées de chênes permettent une exploration en toute liberté, pour la plus grande joie des enfants.","Le musée aéronautique et spatial Safran est riche d’une collection unique de plus de cents moteurs d’avions, réacteurs de fusées, turbines d’hélicoptères ainsi que de nombreuses maquettes d’avions. Ce musée vous invite à découvrir cette passionnante aventure humaine : la conquête du ciel !"};
    String[] ADRESSES ={"Rue Lazare Ponticelli, 77100 Meaux\nHoraire : tous les jours de 9h30 à 18h\nFermé les mardis","31 rue de Paris, 77420 Champs sur Marne\nHoraire : 10h-12h15 13h30-17h\nFermé les mardis","31 rue de Paris, 77420 Champs sur Marne\nHoraire : 10h-12h15 13h30-17h\nFermé les mardis","77300 Fontainebleau\nHoraire : tous les jours de 9h30 à 18h","77950 Maincy\nHoraire : tous les jours de 10h à 19h","77250 Moret-sur-Loing","1 rue du Chateau, 77170 Brie-Comte-Robert\nHoraire : Mercredi de 14h à 17h\nSamedi de 14h30 à 18h","Chemin de Villecran, 77160 Provins","77910 Chambry","2 rue de la Paroisse, 77300 Fontainebleau","Parc des Capucins, 77120 Coulommiers","17 Avenue de la Ferté-sous-Jouarre, 77750 Saint-Cyr-sur-Morin\nHoraire : tous les jours sauf le samedi et mercredi\nDe 10h à 12h30 et de 14h à 17h30","1 rue Dufet-Bourdelle, 77620 Egreville\nHoraire : de mai à octobre de 10h30 à 12h et 14h à 18h","4 promenade Stéphane Mallarmé, 77870 Vulaines-sur-Seine\nHoraire : De mars à octobre de 10h à 12h30 et 14h à 17h30","77630 Barbizon\nHoraire : tous les jours de 10h à 12h30 et 14h à 17h30\nFermé tous les mardi","2 Avenue Louis Delahaye, 77440 Ocquerre","12 rue Rosa Bonheur, 77810 Thomery\nHoraire : tous les jours de 11h à 17h\nFermé les lundi","Place Général de Gaulle, 77 720 La Chapelle-Gauthier\nHoraire : Lundi, vendredi : 16h à 18h \nMercredi : 10h à 12h et de 14h à 17h \nSamedi : 9h à 12h","38 Rue Laurent Poli, 77760 Achères-la-Forêt\nHoraire : Inconnu","rue de l'Eglise, 77320 Amillis\nHoraire : Inconnu","rue Grande, 77760 Amponville\nHoraire : Inconnu","rue de la mairie, 77630 Arbonne la Forêt\nHoraire : Inconnu","place de l'Eglise, 77890 Arville\nHoraire : Inconnu","55 Boulevard du Maréchal Foch, 77300 Fontainebleau\nHoraire : Inconnu","11 Route d'Ormesson, 77720 Auberpierre-Ozouer-le-Repos\nHoraire : Inconnu","Place de Tours, 77115 Blandy\nHoraire : tous les jours de 10h à 18h","1 rue Emile Leclerc, 77000 Melun\nHoraire : tous les jours de 10h à 18h\nFermé tous les mardi","1 rue de l'Etang, 77607 Bussy-St-Martin\nHoraire : tous les jours de 9h à 20h","14 Rue Hoche, 77460 Souppes-sur-Loing\nHoraire : tous les lundi 24h/24","Route de Chevry, 77330 Ozoir-la-Ferrière\nHoraire : tous les jours de 10h à 17h","Rond-point René Ravaud, 77550 Réau\nHoraire : tous les mercredi de 9h à 12h et de 14h à 17h"};
    String[] TARIFS ={"Tarif réduit : 7€\nTarif normal : 10€","Tarif : Gratuit","Tarif réduit : Gratuit\nTarif normal : 8€","Tarif réduit : Gratuit\nTarif normal : 12€","Tarif réduit : 14€90\nTarif normal : 16€90 ","Tarif : Gratuit ","Tarif : Gratuit ","Tarif : Gratuit ","Tarif : Gratuit ","Tarif : Gratuit ","Tarif : Gratuit ","Tarif réduit : Gratuit\nTarif normal : 5€","Tarif réduit : 3€\nTarif normal : 5€","Tarif réduit : 3€\nTarif normal : 5€","Tarif réduit : 4€\nTarif normal : 6€","Tarif : Gratuit ","Tarif réduit : 6€ \nTarif normal : 12€","Tarif : Gratuit","Tarif : Gratuit","Tarif : Gratuit","Tarif : Gratuit","Tarif : Gratuit","Tarif : Gratuit","Tarif : Gratuit","Tarif : Gratuit","Tarif réduit : Gratuit\nTarif normal : 7€","Tarif réduit : 5€\nTarif normal : 7€","Tarif : Gratuit","Tarif réduit : 2€46\nTarif normal : 3€70","Tarif réduit : 14€\nTarif normal : 16€50","Tarif : Gratuit"};
    String[] LIENS ={"https://www.museedelagrandeguerre.eu/","http://www.chateau-champs-sur-marne.fr/","http://www.chateau-champs-sur-marne.fr/","https://www.chateaudefontainebleau.fr/ ","https://vaux-le-vicomte.com/","http://www.ville-moret-sur-loing.com/","http://www.amisduvieuxchateau.org/","https://www.provins.net/","http://www.cheminsdememoire.gouv.fr/fr/chambry-0","https://www.polefontainebleau.fr/patrimoine/saint-louis-de-fontainebleau-3/","https://www.parcsetjardins.fr/jardins/1134-parc-des-capucins","http://www.musee-seine-et-marne.fr/","http://www.musee-jardin-bourdelle.fr/","http://www.musee-mallarme.fr/","http://www.musee-peintres-barbizon.fr/","https://www.paysdelourcq.fr/accueil","https://www.chateau-rosa-bonheur.fr/","http://www.lachapellegauthier77.fr/","http://www.patrimoine-religieux.fr/eglises_edifices/77-Seine-et-Marne/77001-Acheres-la-Foret/174196-EgliseSaint-Fare","https://www.seine-et-marne-attractivite.fr/23858-eglise-saint-pierre-et-sainte-flodoberthe","https://www.seine-et-marne-attractivite.fr/21521-eglise-notre-dame-de-lassomption","https://www.polefontainebleau.fr/patrimoine/eglise-saint-eloi-arbonne/","http://archives.seine-et-marne.fr/arville-eglise-remarquable","https://www.fondation-patrimoine.org/les-projets/chapelle-notre-dame-du-bon-secours-a-fontainebleau","http://www.patrimoine-religieux.fr/eglises_edifices/77-Seine-et-Marne/77010-Aubepierre-Ozouer-le-Repos/165123-EgliseSaint-ChristophedAubepierre","http://www.chateau-blandy.fr/","https://www.gendarmerie.interieur.gouv.fr/musee","https://www.fraciledefrance.com/lieux/chateau/","http://www.tourisme-souppes.fr/index.php/ville-de-tous-les-loisirs-/parc-animalier.html","http://www.zoo-attilly.fr/","https://www.museesafran.com/"};

    private final int SPLASH_SCREEN_TIMEOUT = 1000;

    private Button accueil;
    private Button carte;
    private Button contact;
    private Button filtreAll;
    private Button filtreMusee;
    private Button filtreParcCimetiere;
    private Button filtreChateauHisto;
    private Button filtreEgliseChapelle;
    private String filtre;
    private String filtres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lieux);

        filtre = "tout";
        filtres = "tout";

        final ListView listView = (ListView)findViewById(R.id.liste);
        final CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);

        accueil = findViewById(R.id.accueil);
        accueil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accueil();
            }
        });

        carte = findViewById(R.id.carte);
        carte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carte();
            }
        });

        contact = findViewById(R.id.contact);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contact();
            }
        });

        filtreAll = findViewById(R.id.tout);
        filtreAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filtre = "tout";
                filtres = "tout";
                listView.setAdapter(customAdapter);
            }
        });

        filtreMusee = findViewById(R.id.musee);
        filtreMusee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filtre = "Musée";
                filtres = "Musée";
                listView.setAdapter(customAdapter);
            }
        });

        filtreParcCimetiere = findViewById(R.id.parc);
        filtreParcCimetiere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filtre = "Cimetière";
                filtres = "Parc";
                listView.setAdapter(customAdapter);
            }
        });

        filtreChateauHisto = findViewById(R.id.historique);
        filtreChateauHisto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filtre = "Chateau";
                filtres = "Historique";
                listView.setAdapter(customAdapter);
            }
        });

        filtreEgliseChapelle = findViewById(R.id.eglise);
        filtreEgliseChapelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filtre = "Eglise";
                filtres = "Chapelle";
                listView.setAdapter(customAdapter);
            }
        });

    }

    private void carte(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Carte.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }

    private void accueil(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Accueil.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }
    private void contact(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Contact.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }

    class CustomAdapter extends BaseAdapter{


        @Override
        public int getCount() {
            return IMAGES.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int p = position;
            View view = getLayoutInflater().inflate(R.layout.customlayout, null);

            ImageView imageView = view.findViewById(R.id.illustre);
            TextView textView_name = view.findViewById(R.id.textView_name);
            TextView textView_description = view.findViewById(R.id.textView_descritption);
            TextView textView_adresse = view.findViewById(R.id.textView_adresse);
            TextView textView_tarif = view.findViewById(R.id.textView_tarif);

            if (filtre.equals("tout")){
                imageView.setImageResource(IMAGES[position]);
                textView_name.setText(MONUMENTS[position]);
                textView_description.setText(DESCRIPTIONS[position]);
                textView_adresse.setText(("Adresse : " + ADRESSES[position]));
                textView_tarif.setText((TARIFS[position]));

                view.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(LIENS[p]));
                        startActivity(i);
                    }
                });
            }
            else{
                if (TYPES[position].equals(filtre) || TYPES[position].equals(filtres)){
                    imageView.setImageResource(IMAGES[position]);
                    textView_name.setText(MONUMENTS[position]);
                    textView_description.setText(DESCRIPTIONS[position]);
                    textView_adresse.setText(("Adresse : " + ADRESSES[position]));
                    textView_tarif.setText((TARIFS[position]));

                    view.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View v) {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(LIENS[p]));
                            startActivity(i);
                        }
                    });
                }
                else{
                    imageView.setVisibility(View.GONE);
                    textView_name.setVisibility(View.GONE);
                    textView_name.setVisibility(View.GONE);
                    textView_description.setVisibility(View.GONE);
                    textView_adresse.setVisibility(View.GONE);
                    textView_tarif.setVisibility(View.GONE);
                }
            }




          /*
            for (i=0, ...)
                if (test[i] == ok )
                    view[i].setVisibility(View.VISIBLE);
                else
                    view[i].setVisibility(View.GONE);
*/

            return view;
        }
    }
}
