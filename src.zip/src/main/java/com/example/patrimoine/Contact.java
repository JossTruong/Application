package com.example.patrimoine;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Contact extends AppCompatActivity {
    String[] LIENS = {"https://www.linkedin.com/in/alvina-saakyan/","https://www.linkedin.com/in/julian-mayeux-dut-informatique-15b25a155/", "https://www.linkedin.com/in/josselin-truong/", "https://www.linkedin.com/in/yanis-marzouk-604319155/", "https://www.linkedin.com/in/shédy-marchand-629826134/"};
    int[] IMAGES = {R.drawable.alvina, R.drawable.julian, R.drawable.joss, R.drawable.yanis, R.drawable.shedy};
    String[] NOM = {"Alvina Saakyan", "Julian Mayeux", "Josselin Truong", "Yanis Marzouk", "Shedy Marchand" };

    private final int SPLASH_SCREEN_TIMEOUT = 1000;

    private Button accueil;
    private Button carte;
    private Button lieux;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        accueil = findViewById(R.id.accueil);
        accueil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accueil();
            }
        });

        carte = findViewById(R.id.carte);
        carte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carte();
            }
        });

        lieux = findViewById(R.id.lieux);
        lieux.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lieux();
            }
        });

        ListView listView = (ListView) findViewById(R.id.liste);
        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);
    }

    private void lieux(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Lieux.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }

    private void accueil(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Accueil.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }
    private void carte(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Carte.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }

    class CustomAdapter extends BaseAdapter {


        @Override
        public int getCount() {

            return IMAGES.length;
        }

        @Override
        public Object getItem(int position) {

            return null;
        }

        @Override
        public long getItemId(int position) {

            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int p = position;
            View view = getLayoutInflater().inflate(R.layout.customcontact, null);

            ImageView imageView = view.findViewById(R.id.illustre);
            TextView textView_name = view.findViewById(R.id.textView_descritption);


            imageView.setImageResource(IMAGES[position]);
            textView_name.setText(NOM[position]);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(LIENS[p]));
                    startActivity(i);
                }
            });

            return view;
        }
    }
}
