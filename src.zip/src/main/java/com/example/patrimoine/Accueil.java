package com.example.patrimoine;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Accueil extends AppCompatActivity {

    private final int SPLASH_SCREEN_TIMEOUT = 1000;

    private Button carte;
    private Button lieux;
    private Button contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        carte = findViewById(R.id.carte);
        carte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carte();
            }
        });

        lieux = findViewById(R.id.lieux);
        lieux.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lieux();
            }
        });

        contact = findViewById(R.id.contact);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contact();
            }
        });
    }
    private void lieux(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Lieux.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }

    private void contact(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Contact.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }
    private void carte(){
        setContentView(R.layout.activity_splash);
        //Redirection vers la page principale
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Carte.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_TIMEOUT);
    }
}
